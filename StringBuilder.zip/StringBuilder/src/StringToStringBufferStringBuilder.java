public class StringToStringBufferStringBuilder {
    public static void main(String[] args) {
      
        String str = "Hello, World!";
        System.out.println("Original String: " + str);

     
        StringBuffer stringBuffer = new StringBuffer(str);

      
        StringBuilder stringBuilder = new StringBuilder(str);

       
        System.out.println("String to StringBuffer: " + stringBuffer);
        System.out.println("String to StringBuilder: " + stringBuilder);
    }
}

