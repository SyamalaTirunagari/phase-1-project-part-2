
public class AccessModifiers {

    public String publicVar = "I am a public variable";

    public void publicMethod() {
        System.out.println("This is a public method.");
    }
}

class AnotherClass {
    public static void main(String[] args) {
        AccessModifiers obj = new AccessModifiers();
        System.out.println(obj.publicVar);
        obj.publicMethod();
    }
}