public class InnerClassVerification {

    private int outerVariable = 10;

 
    static class StaticInnerClass {
        void display() {
            System.out.println("Static Inner Class");
        }
    }

    
    class MemberInnerClass {
        void display() {
            System.out.println("Member Inner Class: " + outerVariable);
        }
    }

    public static void main(String[] args) {
       
        StaticInnerClass staticInner = new StaticInnerClass();
        staticInner.display();

       
        InnerClassVerification outer = new InnerClassVerification();
        InnerClassVerification.MemberInnerClass memberInner = outer.new MemberInnerClass();
        memberInner.display();

       
        class LocalInnerClass {
            void display() {
                System.out.println("Local Inner Class");
            }
        }

        LocalInnerClass localInner = new LocalInnerClass();
        localInner.display();

    
        Runnable anonymousInner = new Runnable() {
            @Override
            public void run() {
                System.out.println("Anonymous Inner Class");
            }
        };
        anonymousInner.run();
    }
}
