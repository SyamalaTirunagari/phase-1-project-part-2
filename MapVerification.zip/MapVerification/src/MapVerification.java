import java.util.HashMap;
import java.util.TreeMap;
import java.util.LinkedHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

public class MapVerification {

    public static void main(String[] args) {
        
        Map<String, Integer> hashMap = new HashMap<>();
        hashMap.put("One", 1);
        hashMap.put("Two", 2);
        hashMap.put("Three", 3);
        System.out.println("HashMap: " + hashMap);

        
        Map<String, Integer> treeMap = new TreeMap<>();
        treeMap.put("Orange", 5);
        treeMap.put("Apple", 2);
        treeMap.put("Banana", 3);
        System.out.println("TreeMap: " + treeMap);

       
        Map<String, Integer> linkedHashMap = new LinkedHashMap<>();
        linkedHashMap.put("Zebra", 26);
        linkedHashMap.put("Lion", 12);
        linkedHashMap.put("Elephant", 20);
        System.out.println("LinkedHashMap: " + linkedHashMap);

      
        Map<String, Integer> concurrentHashMap = new ConcurrentHashMap<>();
        concurrentHashMap.put("A", 1);
        concurrentHashMap.put("B", 2);
        concurrentHashMap.put("C", 3);
        System.out.println("ConcurrentHashMap: " + concurrentHashMap);

      
        System.out.println("HashMap size: " + hashMap.size());
        System.out.println("TreeMap size: " + treeMap.size());
        System.out.println("LinkedHashMap size: " + linkedHashMap.size());
        System.out.println("ConcurrentHashMap size: " + concurrentHashMap.size());

        
    }
}
