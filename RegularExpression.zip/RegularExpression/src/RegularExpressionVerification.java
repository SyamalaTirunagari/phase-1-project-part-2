import java.util.regex.*;

public class RegularExpressionVerification {

    public static void main(String[] args) {
       
        String text1 = "The quick brown fox jumps over the lazy dog.";
        String text2 = "123-456-7890";
        String text3 = "Email: example.email123@example.com";

       
        String regex1 = "\\w+";
        Pattern pattern1 = Pattern.compile(regex1);
        Matcher matcher1 = pattern1.matcher(text1);

        System.out.println("Words in text1:");
        while (matcher1.find()) {
            System.out.println(matcher1.group());
        }

        
        String regex2 = "\\d{3}-\\d{3}-\\d{4}";
        Pattern pattern2 = Pattern.compile(regex2);
        Matcher matcher2 = pattern2.matcher(text2);

        System.out.println("\nPhone number in text2:");
        while (matcher2.find()) {
            System.out.println(matcher2.group());
        }

        
        String regex3 = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}";
        Pattern pattern3 = Pattern.compile(regex3);
        Matcher matcher3 = pattern3.matcher(text3);

        System.out.println("\nEmail address in text3:");
        while (matcher3.find()) {
            System.out.println(matcher3.group());
        }
    }
}

