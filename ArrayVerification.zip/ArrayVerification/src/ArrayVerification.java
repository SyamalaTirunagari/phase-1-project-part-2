public class ArrayVerification {

    public static void main(String[] args) {
       
        int[] intArray = new int[5]; 

        
        for (int i = 0; i < intArray.length; i++) {
            intArray[i] = i * 10;
        }

       
        System.out.print("Array elements: ");
        for (int i = 0; i < intArray.length; i++) {
            System.out.print(intArray[i] + " ");
        }
        System.out.println();

       
        int[][] twoDArray = new int[3][3];
        // Initialize 2D array elements
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                twoDArray[i][j] = i + j;
            }
        }

        
        System.out.println("2D Array elements:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(twoDArray[i][j] + " ");
            }
            System.out.println();
        }

       
        String[] stringArray = new String[]{"apple", "banana", "cherry"};
        System.out.print("String Array elements: ");
        for (String str : stringArray) {
            System.out.print(str + " ");
        }
        System.out.println();
    }
}

