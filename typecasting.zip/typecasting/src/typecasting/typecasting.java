package typecasting;

public class typecasting {
	public class Main {

	    public static void main(String[] args) {

	        int num = 9;

	       
	        float numFloat = (float) num;
	        System.out.println("The number after explicit type casting is " + numFloat);

	       
	        double numDouble = num;
	        System.out.println("The number after implicit type casting is " + numDouble);
	    }
	}

}