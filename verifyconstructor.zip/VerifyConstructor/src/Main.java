class ConstructorTypes {
    int a;

    // Constructor type 1: Default constructor
    ConstructorTypes() {
        a = 10;
    }

    // Constructor type 2: Parameterized constructor
    ConstructorTypes(int a) {
        this.a = a;
    }

    // Constructor type 3: Copy constructor
    ConstructorTypes(ConstructorTypes c) {
        this.a = c.a;
    }
}

public class Main {
    public static void main(String[] args) {
        // Verifying default constructor
        ConstructorTypes c1 = new ConstructorTypes();
        System.out.println("Default constructor: " + c1.a);

        // Verifying parameterized constructor
        ConstructorTypes c2 = new ConstructorTypes(20);
        System.out.println("Parameterized constructor: " + c2.a);

        // Verifying copy constructor
        ConstructorTypes c3 = new ConstructorTypes(c2);
        System.out.println("Copy constructor: " + c3.a);
    }
}